package com.example.recomapp.ui.main

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.adapter.StockAdapter
import com.example.recomapp.databinding.FragmentAllStockBinding
import com.example.recomapp.model.Stok
import com.google.firebase.firestore.FirebaseFirestore

class AllStockFragment : Fragment() {
    private lateinit var adapter: StockAdapter
    private lateinit var binding: FragmentAllStockBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentAllStockBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = StockAdapter()
        binding.rvAllStock.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAllStock.adapter = adapter
        fetchAllStock()
    }

    private fun fetchAllStock() {
        binding.progressBar.visibility = View.VISIBLE
        FirebaseFirestore.getInstance()
            .collection("stocks")
            .get()
            .addOnSuccessListener { snapshot ->
                val list = snapshot.documents.mapNotNull { doc ->
                    val name = doc.getString("namaBarang")
                    val kode = doc.getString("kodeBarang")
                    val stokToko = doc.getLong("sisaToko")?.toInt() ?: 0
                    val stokGudang = doc.getLong("sisaGudang")?.toInt() ?: 0
                    val hargaJual = doc.getLong("hargajual")?.toFloat() ?: 0f
                    if (name != null && kode != null)
                        Stok(name, kode.trim().uppercase(), stokToko, stokGudang, hargaJual)
                    else null
                }
                adapter.submitList(list)
                binding.progressBar.visibility = View.GONE
            }
            .addOnFailureListener {
                binding.progressBar.visibility = View.GONE
            }
    }
}

