package com.example.recomapp.ui.settings

import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.recomapp.databinding.ActivityThemeBinding

class ThemeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityThemeBinding
    private val sharedPref by lazy { getSharedPreferences("Settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThemeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load saved theme preference
        when (sharedPref.getString("theme", "light")) {
            "light" -> binding.switchLight.isChecked = true
            "dark" -> binding.switchDark.isChecked = true
            "system" -> binding.switchSystem.isChecked = true
        }

        binding.switchLight.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.switchDark.isChecked = false
                binding.switchSystem.isChecked = false
                setTheme(AppCompatDelegate.MODE_NIGHT_NO, "light")
            }
        }

        binding.switchDark.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.switchLight.isChecked = false
                binding.switchSystem.isChecked = false
                setTheme(AppCompatDelegate.MODE_NIGHT_YES, "dark")
            }
        }

        binding.switchSystem.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.switchLight.isChecked = false
                binding.switchDark.isChecked = false
                setTheme(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, "system")
            }
        }

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun setTheme(mode: Int, theme: String) {
        AppCompatDelegate.setDefaultNightMode(mode)
        sharedPref.edit().putString("theme", theme).apply()
    }
}
