package com.example.recomapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R
import com.example.recomapp.model.Transaksi

class TransaksiAdapter(private val transaksiList: List<Transaksi>) :
    RecyclerView.Adapter<TransaksiAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTanggal: TextView = view.findViewById(R.id.tvTanggal)
        val tvKodeBarang: TextView = view.findViewById(R.id.tvKodeBarang)
        val tvNamaBarang: TextView = view.findViewById(R.id.tvNamaBarang)
        val tvJumlah: TextView = view.findViewById(R.id.tvJumlah)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preview, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val transaksi = transaksiList[position]
        holder.tvTanggal.text = transaksi.tanggal
        holder.tvKodeBarang.text = transaksi.kodeBarang
        holder.tvNamaBarang.text = transaksi.namaBarang
        holder.tvJumlah.text = transaksi.qty.toString()
    }

    override fun getItemCount() = transaksiList.size
}
