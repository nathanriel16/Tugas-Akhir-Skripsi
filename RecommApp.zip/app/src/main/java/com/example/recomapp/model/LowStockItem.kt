package com.example.recomapp.model

data class LowStockItem(
    val namaBarang: String,
    val kodeBarang: String,
    val stokToko: Int,
    val stokGudang: Int,
    val recommendedAddition: Int
)
