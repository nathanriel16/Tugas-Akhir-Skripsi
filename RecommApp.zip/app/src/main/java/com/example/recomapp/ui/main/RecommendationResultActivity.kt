package com.example.recomapp.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.adapter.SalesReportAdapter
import com.example.recomapp.adapter.SalesReportAdapter.ProductReport
import com.example.recomapp.databinding.ActivityRecommendationResultBinding
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi

class RecommendationResultActivity : AppCompatActivity() {

    private lateinit var transaksiList: List<Transaksi>
    private lateinit var stokList: List<Stok>
    private lateinit var binding: ActivityRecommendationResultBinding

    private lateinit var adapter: SalesReportAdapter
    private lateinit var reportList: List<ProductReport>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRecommendationResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ambil data dari intent
        transaksiList = intent.getParcelableArrayListExtra("transaksiList") ?: emptyList()
        stokList = intent.getParcelableArrayListExtra("stokList") ?: emptyList()

        // Buat report list
        reportList = generateProductReports()

        // Setup RecyclerView
        adapter = SalesReportAdapter(reportList)
        binding.rvProductList.layoutManager = LinearLayoutManager(this)
        binding.rvProductList.adapter = adapter

        // Tampilkan angka di tvOverallBalance (misal total penjualan)
        val totalPenjualan = transaksiList.sumOf { it.qty } //harusnya harga
        binding.tvOverallBalance.text = totalPenjualan.toString()

        // Event klik tombol Top Sales dan Stocks
        binding.btnTopSales.setOnClickListener {
            val sortedBySales = reportList.sortedByDescending { it.sold }
            adapter.updateData(sortedBySales)
        }

        binding.btnStocks.setOnClickListener {
            val sortedByStock = stokList.sortedBy { it.sisaToko }
                .map { stok ->
                    ProductReport(
                        name = stok.namaBarang,
                        sold = 0,
                        profit = 0.0
                    )
                }
            adapter.updateData(sortedByStock)
        }
    }

    private fun generateProductReports(): List<ProductReport> {
        return transaksiList.groupBy { it.namaBarang }
            .map { (namaProduk, listTransaksi) ->
                val totalQty = listTransaksi.sumOf { it.qty }
                val hargaSatuan = listTransaksi.firstOrNull()?.qty?.toDouble() ?: 0.0
                val profit = totalQty * hargaSatuan

                ProductReport(
                    name = namaProduk,
                    sold = totalQty,
                    profit = profit
                )
            }.sortedByDescending { it.sold }
    }
}
