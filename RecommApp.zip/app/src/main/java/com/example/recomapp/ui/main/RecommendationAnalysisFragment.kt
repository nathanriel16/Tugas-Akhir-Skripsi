package com.example.recomapp.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.recomapp.R
import com.example.recomapp.databinding.FragmentRecommendationAnalysisBinding
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi

class RecommendationAnalysisFragment : Fragment() {

    private var _binding: FragmentRecommendationAnalysisBinding? = null
    private val binding get() = _binding!!

    private lateinit var transaksiList: List<Transaksi>
    private lateinit var stokList: List<Stok>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecommendationAnalysisBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Ambil data dari arguments
        transaksiList = arguments?.getParcelableArrayList("transaksiList") ?: emptyList()
        stokList = arguments?.getParcelableArrayList("stokList") ?: emptyList()

        analyzeData()

        binding.btnToRecommendation.setOnClickListener {
            // Cegah klik berulang
            it.isEnabled = false

            val existingFragment =
                parentFragmentManager.findFragmentByTag("RecommendationResultFragment")
            if (existingFragment == null) {
                val bundle = Bundle().apply {
                    putParcelableArrayList("transaksiList", ArrayList(transaksiList))
                    putParcelableArrayList("stokList", ArrayList(stokList))
                }

                val resultFragment = RecommendationResultFragment().apply {
                    arguments = bundle
                }

                parentFragmentManager.beginTransaction()
                    .replace(
                        R.id.fragment_container,
                        resultFragment,
                        "RecommendationResultFragment"
                    )
                    .disallowAddToBackStack()
                    .commit()
            }
        }

    }

    private fun analyzeData() {
        // Hitung jumlah pembelian per produk
        val pembelianPerProduk = transaksiList.groupBy { it.namaBarang }
            .mapValues { entry -> entry.value.sumOf { it.qty } }

        // Cari produk dengan stok rendah (misal < 10)
        val stokRendah = stokList.filter { it.sisaToko < 10 }

        // Bangun string hasil analisis
        val analisisString = buildString {
            append("📊 Jumlah Pembelian per Produk:\n")
            pembelianPerProduk.forEach { (produk, jumlah) ->
                append("• $produk: $jumlah kali\n")
            }

            append("\n⚠️ Produk dengan stok rendah (Stok Toko):\n")
            if (stokRendah.isNotEmpty()) {
                stokRendah.forEach {
                    append("• ${it.namaBarang} (Kode: ${it.kodeBarang}): ${it.sisaToko} item\n")
                }
            } else {
                append("Tidak ada stok yang rendah.\n")
            }
        }

        // Tampilkan hasil analisis
        binding.tvAnalysis.text = analisisString
    }

    override fun onResume() {
        super.onResume()
        binding.btnToRecommendation.isEnabled = true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
