package com.example.recomapp.ui.login

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.recomapp.R
import com.example.recomapp.databinding.ActivityLoginBinding
import com.example.recomapp.ui.main.MainActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Toggle password visibility
        binding.passwordTextInputLayout.setEndIconOnClickListener {
            togglePasswordVisibility()
        }

        // Login button click
        binding.btnLogin.setOnClickListener {
            val username = binding.usernameEdtText.text.toString().trim()
            val password = binding.passwordEdtText.text.toString().trim()

            // Validasi form
            if (!validateForm(username, password)) return@setOnClickListener

            // Proses login: cari email berdasarkan username, lalu login
            getEmailAndLogin(username, password)
        }
    }

    private fun validateForm(username: String, password: String): Boolean {
        return when {
            username.isEmpty() || password.isEmpty() -> {
                showToast("Username dan Password tidak boleh kosong")
                false
            }
            !username.matches(Regex("^[a-zA-Z0-9_]{4,}$")) -> {
                showToast("Username minimal 4 karakter, hanya huruf/angka/underscore")
                false
            }
            password.length < 6 -> {
                showToast("Password minimal 6 karakter")
                false
            }
            else -> true
        }
    }

    private fun getEmailAndLogin(username: String, password: String) {
        binding.loadingProgressBar.visibility = View.VISIBLE

        firestore.collection("users")
            .whereEqualTo("username", username)
            .limit(1)
            .get()
            .addOnSuccessListener { documents ->
                binding.loadingProgressBar.visibility = View.GONE
                if (!documents.isEmpty) {
                    val document = documents.documents[0]
                    val email = document.getString("email")

                    if (!email.isNullOrEmpty()) {
                        loginUser(email, password)
                    } else {
                        showToast("Email tidak ditemukan!")
                    }
                } else {
                    showToast("Username tidak ditemukan!")
                }
            }
            .addOnFailureListener {
                binding.loadingProgressBar.visibility = View.GONE
                showToast("Gagal mengambil data: ${it.message}")
            }
    }

    private fun loginUser(email: String, password: String) {
        binding.loadingProgressBar.visibility = View.VISIBLE

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                binding.loadingProgressBar.visibility = View.GONE
                if (task.isSuccessful) {
                    showToast("Login Berhasil!")
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    val errorMessage = getFriendlyLoginError(task.exception?.message)
                    showToast(errorMessage)
                }
            }
    }

    private fun getFriendlyLoginError(message: String?): String {
        return when {
            message?.contains("password is invalid") == true -> "Password salah"
            message?.contains("no user record") == true -> "User tidak ditemukan"
            else -> "Login gagal: ${message ?: "Terjadi kesalahan"}"
        }
    }

    private fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible

        val drawable = if (isPasswordVisible) {
            ContextCompat.getDrawable(this, R.drawable.ic_visibility_off_24px)
        } else {
            ContextCompat.getDrawable(this, R.drawable.ic_visibility_24px)
        }

        binding.passwordTextInputLayout.endIconDrawable = drawable

        if (isPasswordVisible) {
            binding.passwordEdtText.transformationMethod = null
            binding.passwordEdtText.inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            binding.passwordEdtText.transformationMethod = PasswordTransformationMethod.getInstance()
            binding.passwordEdtText.inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        // Set cursor di akhir teks
        binding.passwordEdtText.text?.let {
            binding.passwordEdtText.setSelection(it.length)
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this@LoginActivity, message, Toast.LENGTH_SHORT).show()
    }

    override fun onStart() {
        super.onStart()
        // Jika sudah login, langsung ke MainActivity
        auth.currentUser?.let {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
