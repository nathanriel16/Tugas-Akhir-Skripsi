package com.example.recomapp.model
data class Note(
    var id: String = "",
    var content: String = "",
    var timestamp: Long = System.currentTimeMillis()
)

