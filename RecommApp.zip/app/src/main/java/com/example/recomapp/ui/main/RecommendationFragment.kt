package com.example.recomapp.ui.main

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.recomapp.R
import com.example.recomapp.databinding.FragmentRecommendationBinding
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.text.SimpleDateFormat
import java.util.Locale
import com.google.gson.Gson
import java.io.File

//HALAMAN UNTUK UPLOAD FILE EXCEL + PROSES PARSING DATA EXCEL
class RecommendationFragment : Fragment() {
    private var _binding: FragmentRecommendationBinding? = null
    private val binding get() = _binding!!
    private var noteListener: ListenerRegistration? = null
    private lateinit var tvFileTransaksi: TextView
    private lateinit var tvFileStok: TextView
    private lateinit var btnUploadTransaksi: Button
    private lateinit var btnUploadStok: Button
    private lateinit var btnStartAnalytics: Button
    private lateinit var btninfo: ImageButton
    private val db = FirebaseFirestore.getInstance()

    private var transaksiList: List<Transaksi> = emptyList()
    private var stokList: List<Stok> = emptyList()
    private var currentUploadType: String = ""

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { handleFileSelection(it) }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRecommendationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        // Bind UI elements
        tvFileTransaksi = binding.tvNamaFileTransaksi
        tvFileStok = binding.tvNamaFileStok
        btnUploadTransaksi = binding.btnUploadTransaksi
        btnUploadStok = binding.btnUploadStok
        btnStartAnalytics = binding.btnStartanalytics
        btninfo = binding.btnInfo


        btninfo.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Tentang Halaman Ini")
                .setMessage(
                    "Halaman ini digunakan untuk mengunggah file transaksi dan stok. " +
                            "Sistem akan menganalisis file yang diunggah untuk memberikan rekomendasi " +
                            "penjualan dan pengelolaan stok yang lebih baik."
                )
                .setPositiveButton("Tutup") { dialog, _ -> dialog.dismiss() }
                .show()
        }


        // File transaksi
        btnUploadTransaksi.setOnClickListener {
            currentUploadType = "transaksi"
            filePickerLauncher.launch("*/*")
        }

        // File stok
        btnUploadStok.setOnClickListener {
            currentUploadType = "stok"
            filePickerLauncher.launch("*/*")
        }

        // Lanjut ke preview
        btnStartAnalytics.setOnClickListener {
            if (transaksiList.isNotEmpty() && stokList.isNotEmpty()) {

                uploadTransaksiToFirestore(transaksiList)
                uploadStokToFirestore(stokList)

                val gson = Gson()

                // Simpan file transaksi.json
                val transaksiFile = File(requireContext().cacheDir, "transaksi.json")
                transaksiFile.writeText(gson.toJson(transaksiList))

                // Simpan file stok.json
                val stokFile = File(requireContext().cacheDir, "stok.json")
                stokFile.writeText(gson.toJson(stokList))

                // Kirim path ke fragment
                val bundle = Bundle().apply {
                    putString("transaksiPath", transaksiFile.absolutePath)
                    putString("stokPath", stokFile.absolutePath)
                }

                val fragment = DataPreviewFragment().apply {
                    arguments = bundle
                }

                requireActivity().supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
                requireActivity().supportFragmentManager.beginTransaction()
                    .replace(R.id.container, fragment)
                    .commit()


            } else {
                Toast.makeText(requireContext(), "Silakan upload kedua file terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleFileSelection(uri: Uri) {
        val fileName = getFileName(uri)
        when (currentUploadType) {
            "transaksi" -> {
                transaksiList = parseTransaksiFile(uri)
                tvFileTransaksi.text = fileName
                Toast.makeText(context, "File transaksi berhasil diproses", Toast.LENGTH_SHORT).show()
            }
            "stok" -> {
                stokList = parseStokFile(uri)
                tvFileStok.text = fileName
                Toast.makeText(context, "File stok berhasil diproses", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun uploadTransaksiToFirestore(transaksiList: List<Transaksi>) {
        val transaksiCollection = db.collection("transactions")
        transaksiList.forEach { transaksi ->
            // Mengecek apakah data sudah ada
            val query = transaksiCollection.whereEqualTo("kodeBarang", transaksi.kodeBarang).limit(1)
            query.get().addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) {
                    transaksiCollection.add(transaksi)  // Hanya tambahkan jika belum ada
                        .addOnSuccessListener {
                            println("Berhasil upload transaksi: ${transaksi.kodeBarang}")
                        }
                        .addOnFailureListener { e ->
                            println("Gagal upload transaksi: ${transaksi.kodeBarang}, error: $e")
                        }
                } else {
                    // Data sudah ada, bisa diupdate atau diabaikan
                    println("Transaksi dengan kode barang ${transaksi.kodeBarang} sudah ada.")
                }
            }
        }
    }


    private fun uploadStokToFirestore(stokList: List<Stok>) {
        val stokCollection = db.collection("stocks")
        stokList.forEach { stok ->
            // Mengecek apakah data sudah ada
            val query = stokCollection.whereEqualTo("kodeBarang", stok.kodeBarang).limit(1)
            query.get().addOnSuccessListener { snapshot ->
                if (snapshot.isEmpty) {
                    stokCollection.add(stok)  // Hanya tambahkan jika belum ada
                        .addOnSuccessListener {
                            println("Berhasil upload stok: ${stok.kodeBarang}")
                        }
                        .addOnFailureListener { e ->
                            println("Gagal upload stok: ${stok.kodeBarang}, error: $e")
                        }
                } else {
                    // Data sudah ada, bisa diupdate atau diabaikan
                    println("Transaksi dengan kode barang ${stok.kodeBarang} sudah ada.")
                }
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        val cursor = requireContext().contentResolver.query(uri, null, null, null, null)
        var name = "Unknown"
        cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1) {
                    name = it.getString(nameIndex)
                }
            }
        }
        return name
    }
    private fun parseTransaksiFile(uri: Uri): List<Transaksi> {
        val list = mutableListOf<Transaksi>()
        try {
            val inputStream = requireContext().contentResolver.openInputStream(uri)
            val workbook = XSSFWorkbook(inputStream)
            val sheet = workbook.getSheetAt(0)

            // Baca header
            val headerRow = sheet.getRow(0)
            val headerMap = mutableMapOf<String, Int>()

            for (cellIndex in 0 until headerRow.physicalNumberOfCells) {
                val cellValue = headerRow.getCell(cellIndex).stringCellValue.trim().lowercase()
                headerMap[cellValue] = cellIndex
            }

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i)

                val tanggalCell = row?.getCell(headerMap["tanggal"] ?: -1)
                val kodeBarangCell = row?.getCell(headerMap["kodebarang"] ?: -1)
                val namaBarangCell = row?.getCell(headerMap["namabarang"] ?: -1)
                val qtyCell = row?.getCell(headerMap["qty"] ?: -1)
                val hargaJualCell = row?.getCell(headerMap["hjual"] ?: -1)
                val subtotalCell = row?.getCell(headerMap["jjual"] ?: -1)
                val noNotaCell = row?.getCell(headerMap["nota"] ?: -1)
                val noTransaksiCell = row?.getCell(headerMap["notrans"] ?: -1)

                val tanggal = when (tanggalCell?.cellType) {
                    CellType.STRING -> tanggalCell.stringCellValue
                    CellType.NUMERIC -> {
                        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
                        dateFormat.format(tanggalCell.dateCellValue)
                    }
                    else -> ""
                }

                val kodeBarang = when (kodeBarangCell?.cellType) {
                    CellType.STRING -> kodeBarangCell.stringCellValue
                    CellType.NUMERIC -> kodeBarangCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                val namaBarang = when (namaBarangCell?.cellType) {
                    CellType.STRING -> namaBarangCell.stringCellValue
                    CellType.NUMERIC -> namaBarangCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                val qty = when (qtyCell?.cellType) {
                    CellType.NUMERIC -> qtyCell.numericCellValue.toInt()
                    CellType.STRING -> qtyCell.stringCellValue.toIntOrNull() ?: 0
                    else -> 0
                }

                val hargajual = when (hargaJualCell?.cellType) {
                    CellType.NUMERIC -> hargaJualCell.numericCellValue.toFloat()
                    CellType.STRING -> hargaJualCell.stringCellValue.toFloatOrNull() ?: 0f
                    else -> 0f
                }

                val subtotal = when (subtotalCell?.cellType) {
                    CellType.NUMERIC -> subtotalCell.numericCellValue.toFloat()
                    CellType.STRING -> subtotalCell.stringCellValue.toFloatOrNull() ?: 0f
                    else -> 0f
                }

                val noNota = when (noNotaCell?.cellType) {
                    CellType.STRING -> noNotaCell.stringCellValue
                    CellType.NUMERIC -> noNotaCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                val noTransaksi = when (noTransaksiCell?.cellType) {
                    CellType.STRING -> noTransaksiCell.stringCellValue
                    CellType.NUMERIC -> noTransaksiCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                if (kodeBarang.isNotBlank()) {
                    list.add(Transaksi(kodeBarang, namaBarang, qty, tanggal, hargajual, subtotal, noNota, noTransaksi))
                }
            }

            workbook.close()
            inputStream?.close()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Gagal membaca file transaksi: ${e.message}", Toast.LENGTH_SHORT).show()
        }
        return list
    }

    private fun parseStokFile(uri: Uri): List<Stok> {
        val list = mutableListOf<Stok>()
        try {
            val inputStream = requireContext().contentResolver.openInputStream(uri)
            val workbook = XSSFWorkbook(inputStream)
            val sheet = workbook.getSheetAt(0)

            // Baca header
            val headerRow = sheet.getRow(0)
            val headerMap = mutableMapOf<String, Int>()

            for (cellIndex in 0 until headerRow.physicalNumberOfCells) {
                val cellValue = headerRow.getCell(cellIndex).stringCellValue.trim().lowercase()
                headerMap[cellValue] = cellIndex
            }

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i)

                val kodeBarangCell = row?.getCell(headerMap["kodebarang"] ?: -1)
                val namaBarangCell = row?.getCell(headerMap["namabarang"] ?: -1)
                val stokTokoCell = row?.getCell(headerMap["sisatoko"] ?: -1)
                val stokGudangCell = row?.getCell(headerMap["sisagudang"] ?: -1)
                val hargaJualCell = row?.getCell(headerMap["hargajual"] ?: -1)

                val kodeBarang = when (kodeBarangCell?.cellType) {
                    CellType.STRING -> kodeBarangCell.stringCellValue
                    CellType.NUMERIC -> kodeBarangCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                val namaBarang = when (namaBarangCell?.cellType) {
                    CellType.STRING -> namaBarangCell.stringCellValue
                    CellType.NUMERIC -> namaBarangCell.numericCellValue.toInt().toString()
                    else -> ""
                }

                val stokToko = when (stokTokoCell?.cellType) {
                    CellType.NUMERIC -> stokTokoCell.numericCellValue.toInt()
                    CellType.STRING -> stokTokoCell.stringCellValue.toIntOrNull() ?: 0
                    else -> 0
                }

                val stokGudang = when (stokGudangCell?.cellType) {
                    CellType.NUMERIC -> stokGudangCell.numericCellValue.toInt()
                    CellType.STRING -> stokGudangCell.stringCellValue.toIntOrNull() ?: 0
                    else -> 0
                }

                val hargajual = when (hargaJualCell?.cellType) {
                    CellType.NUMERIC -> hargaJualCell.numericCellValue.toFloat()
                    CellType.STRING -> hargaJualCell.stringCellValue.toFloatOrNull() ?: 0f
                    else -> 0f
                }

                if (kodeBarang.isNotBlank()) {
                    list.add(Stok(kodeBarang, namaBarang, stokToko, stokGudang, hargajual))
                }
            }

            workbook.close()
            inputStream?.close()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Gagal membaca file stok: ${e.message}", Toast.LENGTH_SHORT).show()
        }
        return list
    }

    override fun onDestroyView() {
        super.onDestroyView()
        noteListener?.remove()  // remove Firestore listener
        _binding = null
    }
    override fun onPause() {
        super.onPause()
        noteListener?.remove()  // Stop Firestore listener when the fragment is paused
    }
}
