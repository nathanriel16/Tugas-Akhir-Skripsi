package com.example.recomapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.databinding.ItemAnalysisBinding

class AnalysisAdapter(private val analysisList: List<String>) :
    RecyclerView.Adapter<AnalysisAdapter.AnalysisViewHolder>() {

    inner class AnalysisViewHolder(val binding: ItemAnalysisBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnalysisViewHolder {
        val binding = ItemAnalysisBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AnalysisViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AnalysisViewHolder, position: Int) {
        val item = analysisList[position]
        holder.binding.tvAnalysisText.text = item

        // Supaya text bisa multiline
        holder.binding.tvAnalysisText.isSingleLine = false

        // Tambahkan padding programmatically (kalau mau)
        val padding = (8 * holder.binding.root.resources.displayMetrics.density).toInt()
        holder.binding.root.setPadding(padding, padding, padding, padding)
    }

    override fun getItemCount(): Int = analysisList.size
}
