package com.example.recomapp.adapter

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R
import com.example.recomapp.model.RecommendationResult
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Locale
import android.content.Context as Context1
import java.util.*

class RecommendationAdapter(
    private val items: List<RecommendationResult>,
    private val onItemClick: (RecommendationResult) -> Unit
) : RecyclerView.Adapter<RecommendationAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvSummary: TextView = view.findViewById(R.id.tvSummary)

        init {
            view.setOnClickListener {
                onItemClick(items[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_recommendation, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        // Format tanggal generate rekomendasi (DD-MM-YYYY)
        val formattedDate = item.tanggal?.toDate()?.let { date ->
            SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(date)
        } ?: "Tanggal tidak tersedia"

        // Set judul dengan tanggal rekomendasi
        holder.tvTitle.text = item.judul
        holder.tvSummary.text = item.kesimpulan
    }

    override fun getItemCount(): Int = items.size
}
