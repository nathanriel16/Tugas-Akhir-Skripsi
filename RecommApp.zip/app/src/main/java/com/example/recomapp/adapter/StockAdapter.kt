package com.example.recomapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.databinding.StockItemBinding
import com.example.recomapp.model.Stok

class StockAdapter : ListAdapter<Stok, StockAdapter.StockViewHolder>(DiffCallback()) {

    class StockViewHolder(private val binding: StockItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Stok) {
            binding.tvItemName.text = item.namaBarang
            binding.tvItemCode.text = item.kodeBarang
            val totalStock = item.sisaToko + item.sisaGudang
            binding.tvStockCount.text = "$totalStock pcs"

            // Set warna indikator
            val context = binding.root.context
            val color = when {
                totalStock <= 5 -> android.R.color.holo_red_light   // Sangat sedikit
                totalStock <= 15 -> android.R.color.holo_orange_light // Cukup sedikit
                else -> android.R.color.holo_green_light            // Aman
            }
            binding.stockIndicator.setBackgroundColor(context.getColor(color))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StockViewHolder {
        val binding = StockItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StockViewHolder(binding)
    }

    override fun onBindViewHolder(holder: StockViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DiffCallback : DiffUtil.ItemCallback<Stok>() {
        override fun areItemsTheSame(oldItem: Stok, newItem: Stok): Boolean {
            return oldItem.kodeBarang == newItem.kodeBarang
        }

        override fun areContentsTheSame(oldItem: Stok, newItem: Stok): Boolean {
            return oldItem == newItem
        }
    }
}
