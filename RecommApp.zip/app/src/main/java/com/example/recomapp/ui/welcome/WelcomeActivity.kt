package com.example.recomapp.ui.welcome

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.recomapp.R
import com.example.recomapp.databinding.ActivityWelcomeBinding
import com.example.recomapp.ui.login.LoginActivity
import com.example.recomapp.ui.main.MainActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class WelcomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.loadingProgressBar.visibility = View.VISIBLE

        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            val userRef = FirebaseFirestore.getInstance().collection("users").document(currentUser.uid)
            userRef.get().addOnSuccessListener { document ->
                if (document.exists()) {
                    binding.loadingProgressBar.visibility = View.INVISIBLE
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    binding.loadingProgressBar.visibility = View.INVISIBLE
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()

                }
            }.addOnFailureListener { exception ->
                binding.loadingProgressBar.visibility = View.INVISIBLE
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        } else {
            binding.loadingProgressBar.visibility = View.INVISIBLE
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}