package com.example.recomapp.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.recomapp.databinding.FragmentRecommendationResultBinding
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi

class RecommendationResultFragment : Fragment() {

    private var _binding: FragmentRecommendationResultBinding? = null
    private val binding get() = _binding!!

    private lateinit var transaksiList: List<Transaksi>
    private lateinit var stokList: List<Stok>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecommendationResultBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Ambil data dari arguments
        transaksiList = arguments?.getParcelableArrayList("transaksiList") ?: emptyList()
        stokList = arguments?.getParcelableArrayList("stokList") ?: emptyList()

        // Menampilkan rekomendasi
        val rekomendasi = getRecommendation()

        binding.tvRecommendation.text = rekomendasi
    }

    private fun getRecommendation(): String {
        // Menghitung rekomendasi berdasar pembelian produk dan stok
        val rekomendasiString = buildString {
            append("💡 Rekomendasi Produk:\n")

            // Logika untuk rekomendasi berdasarkan pembelian dan stok
            val pembelianPerProduk = transaksiList.groupBy { it.namaBarang }
                .mapValues { entry -> entry.value.sumOf { it.qty } }

            stokList.forEach {
                if (it.sisaToko < 10) {
                    append("• ${it.namaBarang} (Kode: ${it.kodeBarang}): Perlu restock, stok rendah\n")
                }
            }

            append("\nRekomendasi Produk yang Sering Dibeli Bersama:\n")
            // Misalnya menggunakan pola pembelian untuk rekomendasi produk lain
            for (produk in pembelianPerProduk) {
                append("• ${produk.key}: Berdasarkan pembelian produk ini, kami merekomendasikan produk lain untuk dibeli.\n")
            }
        }

        return rekomendasiString
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
