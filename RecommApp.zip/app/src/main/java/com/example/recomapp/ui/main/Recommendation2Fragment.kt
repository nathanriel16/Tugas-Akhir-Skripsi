package com.example.recomapp.ui.main

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.R
import com.example.recomapp.adapter.RecommendationAdapter
import com.example.recomapp.databinding.DialogNoteBinding
import com.example.recomapp.databinding.DialogRecommresultBinding
import com.example.recomapp.databinding.FragmentRecommendation2Binding
import com.example.recomapp.model.Note
import com.example.recomapp.model.RecommendationResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.ktx.toObject

//HALAMAN UNTUK MELIHAT REKOMENDASI
class Recommendation2Fragment : Fragment() {

    private var _binding: FragmentRecommendation2Binding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: RecommendationAdapter
    private var noteListener: ListenerRegistration? = null
    private val recommendationList = mutableListOf<RecommendationResult>()
    private val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecommendation2Binding.inflate(inflater, container, false)

        adapter = RecommendationAdapter(recommendationList) { item ->
            showDetailDialog(item)
        }

        binding.recyclerViewRecommendations.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewRecommendations.adapter = adapter

        binding.fabAddRecommendation.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.container, RecommendationFragment())
                .addToBackStack(null)
                .commit()
        }

        fetchRecommendations()

        return binding.root
    }

    private fun fetchRecommendations() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            Log.e("RecommendationFragment", "User not logged in")
            return
        }
        binding.progressBarChart.visibility = View.VISIBLE
        db.collection("recommendationResult")
            .orderBy("tanggal",com.google.firebase.firestore.Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { result ->
                if (_binding == null) return@addOnSuccessListener
                recommendationList.clear()
                for (document in result) {
                    val item = document.toObject<RecommendationResult>()
                    recommendationList.add(item)
                }
                adapter.notifyDataSetChanged()
                binding.progressBarChart.visibility = View.GONE
            }
            .addOnFailureListener { exception ->
                Log.e("RecommendationFragment", "Error getting documents: ", exception)
            }
    }

    private fun showDetailDialog(item: RecommendationResult) {
        val dialogBinding = DialogRecommresultBinding.inflate(LayoutInflater.from(requireContext()))
        val dialog = AlertDialog.Builder(requireContext(), R.style.DialogTheme2)
            .setView(dialogBinding.root)
            .setCancelable(true) // Lebih user-friendly
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.attributes?.windowAnimations = R.style.DialogAnimation

        // Tampilkan konten dari RecommendationResult
        dialogBinding.dialogTitle.setText(item.judul ?: "Tidak ada judul.")
        dialogBinding.tvRecommresultContent.setText(item.detail ?: "Tidak ada catatan.")
        dialogBinding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        noteListener?.remove()
        _binding = null
    }

    override fun onPause() {
        super.onPause()
        noteListener?.remove()
    }
}
