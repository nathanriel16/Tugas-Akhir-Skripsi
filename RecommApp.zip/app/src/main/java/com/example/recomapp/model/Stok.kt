package com.example.recomapp.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Stok(
    val kodeBarang: String,
    val namaBarang: String,
    val sisaToko: Int = 0,
    val sisaGudang: Int = 0,
    val hargaJual: Float,
) : Parcelable
