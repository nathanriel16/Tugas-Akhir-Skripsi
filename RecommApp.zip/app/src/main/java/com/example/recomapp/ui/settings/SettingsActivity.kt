package com.example.recomapp.ui.settings

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.recomapp.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPref = getSharedPreferences("Settings", MODE_PRIVATE)

        // Load saved preferences
        binding.tvLanguageValue.text = sharedPref.getString("language", getString(com.example.recomapp.R.string.language1))
        binding.tvThemeValue.text = sharedPref.getString("theme", getString(com.example.recomapp.R.string.theme1))

        // Back button action
        binding.ivBack.setOnClickListener {
            finish()
        }

        // Open Account Settings
        binding.accountSetting.setOnClickListener {
            startActivity(Intent(this, AccountActivity::class.java))
        }

        // Open Language Settings
        binding.languageSetting.setOnClickListener {
            startActivity(Intent(this, LanguageActivity::class.java))
        }

        // Open Theme Settings
        binding.themeSetting.setOnClickListener {
            startActivity(Intent(this, ThemeActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Update values when returning to this activity
        binding.tvLanguageValue.text = sharedPref.getString("language", getString(com.example.recomapp.R.string.language1))
        binding.tvThemeValue.text = sharedPref.getString("theme", getString(com.example.recomapp.R.string.theme1))
    }
}
