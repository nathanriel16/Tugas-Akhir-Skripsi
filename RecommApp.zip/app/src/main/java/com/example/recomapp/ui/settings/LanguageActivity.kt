package com.example.recomapp.ui.settings

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.recomapp.databinding.ActivityLanguageBinding
import java.util.*

class LanguageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLanguageBinding
    private val sharedPref by lazy { getSharedPreferences("Settings", MODE_PRIVATE) }

    private var updatingSwitches = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set locale terlebih dahulu
        applySavedLocale()

        binding = ActivityLanguageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load saved language preference
        val savedLanguage = sharedPref.getString("language", "en")

        updateSwitches(savedLanguage)

        binding.switchIndonesia.setOnCheckedChangeListener { _, isChecked ->
            if (!updatingSwitches && isChecked) {
                updateSwitches("id")
                setLocaleAndRestart("id")
            }
        }

        binding.switchEnglish.setOnCheckedChangeListener { _, isChecked ->
            if (!updatingSwitches && isChecked) {
                updateSwitches("en")
                setLocaleAndRestart("en")
            }
        }

        binding.ivBack.setOnClickListener {
            finish()
        }
    }

    private fun updateSwitches(language: String?) {
        updatingSwitches = true
        binding.switchIndonesia.isChecked = language == "id"
        binding.switchEnglish.isChecked = language == "en"
        updatingSwitches = false
    }

    private fun setLocaleAndRestart(language: String) {
        val locale = Locale(language)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        baseContext.resources.updateConfiguration(config, baseContext.resources.displayMetrics)

        // Save language code
        sharedPref.edit().putString("language", language).apply()

        // Restart app or go back to settings to apply language globally
        val intent = Intent(this, SettingsActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    private fun applySavedLocale() {
        val langCode = sharedPref.getString("language", "en") ?: "en"
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        resources.updateConfiguration(config, resources.displayMetrics)
    }
}
