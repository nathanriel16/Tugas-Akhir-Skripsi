package com.example.recomapp.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R
import com.example.recomapp.model.ProductRanking
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.Entry

class RankingAdapter : RecyclerView.Adapter<RankingAdapter.RankingViewHolder>() {

    private val productList = mutableListOf<ProductRanking>()

    fun submitList(data: List<ProductRanking>) {
        productList.clear()
        productList.addAll(data)
        notifyDataSetChanged()
    }


    inner class RankingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRank        = itemView.findViewById<TextView>(R.id.tv_rank)
        private val tvName        = itemView.findViewById<TextView>(R.id.tv_product_name)
        private val tvCode        = itemView.findViewById<TextView>(R.id.tv_product_code)
        private val tvQty         = itemView.findViewById<TextView>(R.id.tv_qty)
        private val tvPercentage  = itemView.findViewById<TextView>(R.id.tv_percentage)
        private val sparklineChart= itemView.findViewById<LineChart>(R.id.trendingitemChart)

        init {
            sparklineChart.apply {
                // hilangkan semua dekorasi
                setViewPortOffsets(0f, 0f, 0f, 0f)
                setBackgroundColor(Color.TRANSPARENT)
                description.isEnabled = false
                legend.isEnabled = false

                setTouchEnabled(false)
                isDragEnabled = false
                setScaleEnabled(false)
                setPinchZoom(false)

                xAxis.apply {
                    isEnabled = false
                }
                axisLeft.apply {
                    isEnabled = false
                }
                axisRight.apply {
                    isEnabled = false
                }
            }
        }

        fun bind(product: ProductRanking, position: Int) {
            tvRank.text       = "${position + 1}."
            tvName.text       = product.productName
            tvCode.text       = product.productCode.ifEmpty { "–" }
            tvQty.text        = "${product.quantity} qty"
            val sign = if (product.growthPercent >= 0) "+" else ""
            tvPercentage.text = "$sign${"%.2f".format(product.growthPercent)}%"

            // set data sparkline
            setSparkline(product.salesTrend)
        }

        private fun setSparkline(salesTrend: List<Float>) {
            if (salesTrend.isEmpty()) {
                sparklineChart.clear()
                return
            }

            val entries = salesTrend.mapIndexed { i, v -> Entry(i.toFloat(), v) }
            val dataSet = LineDataSet(entries, "").apply {
                color = Color.parseColor("#3DDC84")    // hijau misal
                lineWidth = 1.5f
                setDrawCircles(false)
                setDrawValues(false)
            }

            sparklineChart.data = LineData(dataSet)
            sparklineChart.invalidate()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RankingViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.trending_item, parent, false)
        return RankingViewHolder(view)
    }

    override fun onBindViewHolder(holder: RankingViewHolder, position: Int) {
        holder.bind(productList[position], position)
    }

    override fun getItemCount(): Int = productList.size
}
