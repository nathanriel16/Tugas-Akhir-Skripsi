//package com.example.recomapp.ui.main
//
//import android.os.Bundle
//import android.util.Log
//import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
//import androidx.recyclerview.widget.LinearLayoutManager
//import com.example.recomapp.adapter.AnalysisAdapter
//import com.example.recomapp.databinding.ActivityRecommendationAnalysisBinding
//import com.example.recomapp.model.RecommendationResult
//import com.example.recomapp.model.Stok
//import com.example.recomapp.model.Transaksi
//import com.google.firebase.Timestamp
//import com.google.firebase.firestore.FirebaseFirestore
//import com.google.gson.Gson
//import com.google.gson.reflect.TypeToken
//import java.io.File
//import java.text.SimpleDateFormat
//import java.util.Calendar
//import java.util.Date
//import java.util.Locale
//import kotlin.math.sqrt
//
//class RecommendationAnalysisActivity : AppCompatActivity() {
//
//    private lateinit var binding: ActivityRecommendationAnalysisBinding
//    private lateinit var adapter: AnalysisAdapter
//    private lateinit var topRecommendations: List<Pair<Pair<String, String>, Double>>
//    private lateinit var dataTest: List<Transaksi>
//
//    private val db = FirebaseFirestore.getInstance()
//    private var lastTransactionDate: Date? = null
//    private val predictionDurationDays = 30
//    private val similarityThreshold = 0.5
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = ActivityRecommendationAnalysisBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        binding.btnback.setOnClickListener { finish() }
//        readUploadedData()
//    }
//
//    fun pisahkanTransaksi(
//        transaksiList: List<Transaksi>,
//        startTrain: Date,
//        endTrain: Date,
//        startTest: Date,
//        endTest: Date,
//        format: SimpleDateFormat
//    ): Pair<List<Transaksi>, List<Transaksi>> {
//        val dataTrain = transaksiList.filter {
//            val tgl = format.parse(it.tanggal ?: "") ?: return@filter false
//            tgl >= startTrain && tgl <= endTrain
//        }
//        val dataTest = transaksiList.filter {
//            val tgl = format.parse(it.tanggal ?: "") ?: return@filter false
//            tgl >= startTest && tgl <= endTest
//        }
//        return Pair(dataTrain, dataTest)
//    }
//
//    fun hitungTingkatKeberhasilan(
//        rekomendasi: List<Pair<String, String>>,
//        dataUji: List<Transaksi>
//    ): Pair<Int, Int> {
//        val grouped = dataUji.groupBy { it.noNota }
//        val transaksiMap = grouped.mapValues { (_, items) ->
//            items.map { normalizeName(it.kodeBarang) }.toSet()
//        }
//
//        var match = 0
//        for ((a, b) in rekomendasi) {
//            val normA = normalizeName(a)
//            val normB = normalizeName(b)
//            val ditemukan = transaksiMap.values.any { normA in it && normB in it }
//            if (ditemukan) match++
//        }
//        return Pair(match, rekomendasi.size)
//    }
//
//
//    private fun readUploadedData() {
//        val transaksiPath = intent.getStringExtra("transaksiFile")
//        val stokPath = intent.getStringExtra("stokFile")
//
//        if (transaksiPath != null && stokPath != null) {
//            val transaksiFile = File(transaksiPath)
//            val stokFile = File(stokPath)
//
//            val gson = Gson()
//            val transaksiType = object : TypeToken<List<Transaksi>>() {}.type
//            val stokType = object : TypeToken<List<Stok>>() {}.type
//
//            val transaksiListRaw: List<Transaksi> = gson.fromJson(transaksiFile.readText(), transaksiType)
//            val stokList: List<Stok> = gson.fromJson(stokFile.readText(), stokType)
//
//            val transaksiList = transaksiListRaw.map {
//                it.copy(namaBarang = normalizeName(it.namaBarang))
//            }
//
//            Log.d("TransaksiList", gson.toJson(transaksiList))
//
//            // Log setiap transaksi dengan atribut utama
//            transaksiList.forEachIndexed { index, transaksi ->
//                Log.d("TransaksiItem", "Item $index: noTransaksi=${transaksi.noTransaksi}, tanggal=${transaksi.tanggal}, namaBarang=${transaksi.namaBarang}, qty=${transaksi.qty}")
//            }
//
//            analyzeData(transaksiList, stokList)
//        } else {
//            Toast.makeText(this, "Data transaksi atau stok tidak ditemukan", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    fun hitungKeberhasilanPerKombinasi(
//        pasangan: List<Pair<String, String>>,
//        dataUji: List<Transaksi>
//    ): List<Triple<Pair<String, String>, Int, Int>> {
//        val grouped = dataUji.groupBy { it.noNota }
//        val transaksiMap = grouped.mapValues { (_, items) ->
//            items.map { normalizeName(it.kodeBarang) }.toSet()
//        }
//
//        val totalNota = transaksiMap.size
//        val hasil = mutableListOf<Triple<Pair<String, String>, Int, Int>>()
//
//        for ((a, b) in pasangan) {
//            val normA = normalizeName(a)
//            val normB = normalizeName(b)
//
//            val count = transaksiMap.values.count { normA in it && normB in it }
//            hasil.add(Triple(Pair(a, b), count, totalNota))
//        }
//
//        return hasil
//    }
//
//    private fun analyzeData(transaksiList: List<Transaksi>, stokList: List<Stok>) {
//        val format = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
//
//        // 1. Pisahkan data training dan testing sesuai periode skenario
//        val (dataTrain, dataTest) = pisahkanTransaksi(
//            transaksiList,
//            //TODO: skenario1
//            format.parse("02-01-2023")!!, // ⬅️ Mulai training
//            format.parse("16-01-2023")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("17-01-2023")!!, // ⬅️ Mulai prediksi
//            format.parse("23-01-2023")!!, // ⬅️ Akhir prediksi (7 hari)
//            format
//        )
//
//        val analysisResult = mutableListOf<String>()
//
//        // 2. Normalisasi namaBarang dan kodeBarang di dataTrain
//        val normalizedTransaksiList = dataTrain.map {
//            it.copy(
//                namaBarang = normalizeName(it.namaBarang),
//                kodeBarang = normalizeName(it.kodeBarang)
//            )
//        }
//
//        // 3. Ambil tanggal terakhir
//        val transactionDates = dataTrain.mapNotNull {
//            try {
//                format.parse(it.tanggal ?: "")
//            } catch (e: Exception) {
//                null
//            }
//        }
//        lastTransactionDate = transactionDates.maxOrNull() ?: Date()
//        analysisResult.add("\uD83D\uDCC5 Data dianalisis untuk rekomendasi $predictionDurationDays hari ke depan.")
//
//        // 4. Kelompokkan transaksi berdasarkan noNota
//        val transaksiGrouped = normalizedTransaksiList.groupBy { it.noNota }.toSortedMap()
//        val transaksiMatrix = transaksiGrouped.mapValues { (_, items) ->
//            items.groupBy { it.kodeBarang }
//                .mapValues { it.value.sumOf { it.qty.toDouble() } }
//        }
//
//        // 5. Hitung similarity antar barang
//        val allItems = normalizedTransaksiList.map { it.kodeBarang }.distinct()
//        val similarityMap = mutableMapOf<Pair<String, String>, Double>()
//
//        for (i in 0 until allItems.size) {
//            for (j in i + 1 until allItems.size) {
//                val itemA = allItems[i]
//                val itemB = allItems[j]
//
//                val pairedRatings = transaksiMatrix.mapNotNull { (_, items) ->
//                    val qtyA = items[itemA]
//                    val qtyB = items[itemB]
//                    if (qtyA != null && qtyB != null) Pair(qtyA, qtyB) else null
//                }
//
//                if (pairedRatings.size >= 2) {
//                    val dotProduct = pairedRatings.sumOf { it.first * it.second }
//                    val magnitudeA = sqrt(pairedRatings.sumOf { it.first * it.first })
//                    val magnitudeB = sqrt(pairedRatings.sumOf { it.second * it.second })
//                    val similarity = if (magnitudeA != 0.0 && magnitudeB != 0.0)
//                        dotProduct / (magnitudeA * magnitudeB) else 0.0
//
//                    similarityMap[Pair(itemA, itemB)] = similarity
//                    similarityMap[Pair(itemB, itemA)] = similarity
//                }
//            }
//        }
//
//        val sortedSimilarities = similarityMap.toList().sortedByDescending { it.second }
//        val top5Similarities = sortedSimilarities.take(5)
//        val bottom5Similarities = sortedSimilarities.takeLast(5)
//
//        val topRecommendations = top5Similarities.filter { it.second >= similarityThreshold }
//
//        // 6. Tampilkan hasil rekomendasi
//        analysisResult.add("\uD83D\uDCCA Rekomendasi Produk Berdasarkan Cosine Similarity:")
//        topRecommendations.forEachIndexed { index, (pair, sim) ->
//            analysisResult.add("${index + 1}. ${pair.first} dan ${pair.second} (similarity: ${"%.2f".format(sim)})")
//        }
//
//        // 7. Evaluasi: hitung tingkat keberhasilan di dataTest
//        val rekomendasiPasangan = topRecommendations.map { it.first }
//        val hasilPerKombinasi = hitungKeberhasilanPerKombinasi(rekomendasiPasangan, dataTest)
//        val (jumlahCocok, totalRekomendasi) = hitungTingkatKeberhasilan(rekomendasiPasangan, dataTest)
//        val persen = if (totalRekomendasi != 0) (jumlahCocok.toDouble() / totalRekomendasi) * 100 else 0.0
//
//        analysisResult.add("")
//        analysisResult.add("🎯 Evaluasi Offline: $jumlahCocok dari $totalRekomendasi pasangan cocok (${String.format("%.2f", persen)}%)")
//
//        analysisResult.add("\n📊 Detail Evaluasi Per Kombinasi:")
//        hasilPerKombinasi.forEachIndexed { index, (pair, cocok, total) ->
//            val persen = if (total != 0) (cocok.toDouble() / total) * 100 else 0.0
//            analysisResult.add("${index + 1}. ${pair.first} & ${pair.second} muncul di $cocok/$total transaksi pengujian (${String.format("%.2f", persen)}%)")
//        }
//
//        // 8. Tambahkan saran pemesanan ulang
//        val rekomendasiPemesananUlang = mutableListOf<String>()
//        topRecommendations.forEach { (pair, sim) ->
//            val stokBarangA = stokList.find { normalizeName(it.kodeBarang) == pair.first }
//            val stokBarangB = stokList.find { normalizeName(it.kodeBarang) == pair.second }
//
//            if ((stokBarangA?.sisaToko ?: 0) < 10) {
//                rekomendasiPemesananUlang.add("Barang ${pair.first} stok rendah → disarankan pesan ulang bersama ${pair.second} (similarity: ${"%.2f".format(sim)})")
//            }
//            if ((stokBarangB?.sisaToko ?: 0) < 10) {
//                rekomendasiPemesananUlang.add("Barang ${pair.second} stok rendah → disarankan pesan ulang bersama ${pair.first} (similarity: ${"%.2f".format(sim)})")
//            }
//        }
//
//        // 9. Kesimpulan akhir
//        val kesimpulan = if (topRecommendations.isNotEmpty()) {
//            val rekom = topRecommendations.joinToString("\n") { "• ${it.first.first} cocok dengan ${it.first.second}" }
//            "Berikut adalah rekomendasi barang:\n$rekom"
//        } else {
//            "Tidak ditemukan hubungan pembelian signifikan antar produk."
//        }
//
//        analysisResult.add("\n\uD83D\uDCDD $kesimpulan")
//        analysisResult.add("Jumlah transaksi total: ${transaksiList.size}")
//        analysisResult.add("\n\uD83D\uDCE6 Saran Pemesanan Ulang:")
//        analysisResult.addAll(rekomendasiPemesananUlang)
//
//        // 10. Tampilkan di RecyclerView
//        adapter = AnalysisAdapter(analysisResult)
//        binding.rvAnalysis.layoutManager = LinearLayoutManager(this)
//        binding.rvAnalysis.adapter = adapter
//
//        // 11. Simpan ke Firestore
//        val todayString = format.format(Date())
//        val recommendation = RecommendationResult(
//            judul = "Rekomendasi $todayString ($predictionDurationDays Hari Kedepan)",
//            kesimpulan = kesimpulan,
//            detail = analysisResult.joinToString("\n"),
//            tanggal = Timestamp.now()
//        )
//
//        db.collection("recommendationResult")
//            .add(recommendation)
//            .addOnSuccessListener {
//                Toast.makeText(this, "Berhasil disimpan ke Firestore", Toast.LENGTH_SHORT).show()
//            }
//            .addOnFailureListener {
//                Toast.makeText(this, "Gagal menyimpan ke Firestore", Toast.LENGTH_SHORT).show()
//            }
//    }
//
//    // Fungsi normalisasi nama barang
//    fun normalizeName(name: String): String {
//        return name
//            .trim()                         // hapus spasi di awal/akhir
//            .lowercase()                    // huruf kecil semua
//            .replace(Regex("[^a-z0-9 ]"), "") // hapus karakter selain huruf, angka, spasi
//            .replace(Regex("\\s+"), " ")       // ganti spasi berulang jadi satu spasi
//    }
//}
