package com.example.recomapp.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

//testing data class
@Parcelize
data class Transaksi(
    val kodeBarang: String = "",
    val namaBarang: String = "",
    val qty: Int = 0,
    val tanggal: String = "",
    val hargaJual: Float = 0f,
    val subtotal: Float = 0f,
    val noNota: String = "",
    val noTransaksi: String = ""
) : Parcelable {
    // Konstruktor tanpa argumen untuk Firestore deserialization
    constructor() : this("", "", 0, "", 0f, 0f, "", "")
}



//@Parcelize
//data class Transaksi(
//    val kodeBarang: String = "",
//    val namaBarang: String = "",
//    val qty: Int = 0,
//    val tanggal: String = "",
//    val hargaJual: Float = 0f,
//    val subtotal: Float = 0f,
//    val noNota: String = "",
//    val noTransaksi: String=""
//) : Parcelable
