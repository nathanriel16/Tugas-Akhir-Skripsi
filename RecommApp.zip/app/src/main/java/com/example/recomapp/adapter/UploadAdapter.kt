package com.example.recomapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R
import com.example.recomapp.model.UploadFile

class UploadAdapter(
    private val fileList: List<UploadFile>,
    private val onDeleteClick: (UploadFile) -> Unit
) : RecyclerView.Adapter<UploadAdapter.UploadViewHolder>() {

    inner class UploadViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFileName: TextView = view.findViewById(R.id.tv_filename)
        val tvFileSize: TextView = view.findViewById(R.id.tv_filesize)
        val progressBar: ProgressBar = view.findViewById(R.id.pb_upload)
        val ivDelete: ImageView = view.findViewById(R.id.iv_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UploadViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_upload, parent, false)
        return UploadViewHolder(view)
    }

    override fun onBindViewHolder(holder: UploadViewHolder, position: Int) {
        val file = fileList[position]
        holder.tvFileName.text = file.fileName
        holder.tvFileSize.text = file.fileSize
        holder.progressBar.progress = file.uploadProgress

        holder.ivDelete.setOnClickListener {
            onDeleteClick(file)
        }
    }

    override fun getItemCount(): Int = fileList.size
}
