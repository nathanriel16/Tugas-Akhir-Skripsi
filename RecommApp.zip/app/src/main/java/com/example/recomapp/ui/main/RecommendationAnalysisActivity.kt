package com.example.recomapp.ui.main

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.adapter.AnalysisAdapter
import com.example.recomapp.databinding.ActivityRecommendationAnalysisBinding
import com.example.recomapp.model.RecommendationResult
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

//HALAMAN HASIL ANALISA DATA UNTUK MENGHASILKAN REKOMENDASI
class RecommendationAnalysisActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecommendationAnalysisBinding
    private lateinit var adapter: AnalysisAdapter
    private lateinit var topRecommendations: List<Pair<Pair<String, String>, Double>>
    private lateinit var dataTest: List<Transaksi>

    private val db = FirebaseFirestore.getInstance()
    private var lastTransactionDate: Date? = null
    private val predictionDurationDays = 731 //TODO yang harus diubah tiap skenario
    private val similarityThreshold = 0.5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecommendationAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnback.setOnClickListener { finish() }
        readUploadedData()
    }

    fun pisahkanTransaksi(
        transaksiList: List<Transaksi>,
        startTrain: Date,
        endTrain: Date,
        startTest: Date,
        endTest: Date,
        format: SimpleDateFormat
    ): Pair<List<Transaksi>, List<Transaksi>> {
        val dataTrain = transaksiList.filter {
            val tgl = format.parse(it.tanggal ?: "") ?: return@filter false
            tgl in startTrain..endTrain
        }
        val dataTest = transaksiList.filter {
            val tgl = format.parse(it.tanggal ?: "") ?: return@filter false
            tgl in startTest..endTest
        }
        return Pair(dataTrain, dataTest)
    }

    fun hitungTingkatKeberhasilan(
        rekomendasi: List<Pair<String, String>>,
        dataUji: List<Transaksi>
    ): Pair<Int, Int> {
        val grouped = dataUji.groupBy { it.noNota }
        val transaksiMap = grouped.mapValues { (_, items) ->
            items.map { normalizeName(it.kodeBarang) }.toSet()
        }

        var match = 0
        for ((a, b) in rekomendasi) {
            val normA = normalizeName(a)
            val normB = normalizeName(b)
            val ditemukan = transaksiMap.values.any { normA in it && normB in it }
            if (ditemukan) match++
        }
        return Pair(match, rekomendasi.size)
    }


    private fun readUploadedData() {
        val transaksiPath = intent.getStringExtra("transaksiFile")
        val stokPath = intent.getStringExtra("stokFile")

        if (transaksiPath != null && stokPath != null) {
            val transaksiFile = File(transaksiPath)
            val stokFile = File(stokPath)

            val gson = Gson()
            val transaksiType = object : TypeToken<List<Transaksi>>() {}.type
            val stokType = object : TypeToken<List<Stok>>() {}.type

            val transaksiListRaw: List<Transaksi> = gson.fromJson(transaksiFile.readText(), transaksiType)
            val stokList: List<Stok> = gson.fromJson(stokFile.readText(), stokType)

            val transaksiList = transaksiListRaw.map {
                it.copy(namaBarang = normalizeName(it.namaBarang))
            }

            Log.d("TransaksiList", gson.toJson(transaksiList))

            // Log setiap transaksi dengan atribut utama
            transaksiList.forEachIndexed { index, transaksi ->
                Log.d("TransaksiItem", "Item $index: noTransaksi=${transaksi.noTransaksi}, tanggal=${transaksi.tanggal}, namaBarang=${transaksi.namaBarang}, qty=${transaksi.qty}")
            }

            analyzeData(transaksiList, stokList)
        } else {
            Toast.makeText(this, "Data transaksi atau stok tidak ditemukan", Toast.LENGTH_SHORT).show()
        }
    }

    fun hitungKeberhasilanPerKombinasi(
        pasangan: List<Pair<String, String>>,
        dataUji: List<Transaksi>
    ): List<Triple<Pair<String, String>, Int, Int>> {
        val grouped = dataUji.groupBy { it.noNota }
        val transaksiMap = grouped.mapValues { (_, items) ->
            items.map { normalizeName(it.kodeBarang) }.toSet()
        }

        val totalNota = transaksiMap.size
        val hasil = mutableListOf<Triple<Pair<String, String>, Int, Int>>()

        for ((a, b) in pasangan) {
            val normA = normalizeName(a)
            val normB = normalizeName(b)

            val count = transaksiMap.values.count { normA in it && normB in it }
            hasil.add(Triple(Pair(a, b), count, totalNota))
        }

        return hasil
    }

    private fun analyzeData(transaksiList: List<Transaksi>, stokList: List<Stok>) {
        val format = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

        // 1. Pisahkan data training dan testing sesuai periode skenario
        val (dataTrain, dataTest) = pisahkanTransaksi(
            transaksiList,
            // skenario panjang pendek 1 DONE 0%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("01-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("07-09-2024")!!, // ⬅️ Akhir prediksi (7 hari)
//            format
            //skenario panjang pendek 2 DONE 0%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("25-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("01-10-2024")!!, // ⬅️ Akhir prediksi (7 hari)
//            format
            //skenario panjang pendek 3 DONE 0%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("20-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("26-10-2024")!!, // ⬅️ Akhir prediksi (7 hari)
//            format
            //skenario panjang pendek 4 0%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("10-11-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("24-11-2024")!!, // ⬅️ Akhir prediksi (15 hari)
//            format
            //skenario panjang pendek 5 20%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("05-12-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("19-12-2024")!!, // ⬅️ Akhir prediksi (15 hari)
//            format
            //skenario panjang pendek 6 20%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("15-12-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("29-12-2024")!!, // ⬅️ Akhir prediksi (15 hari)
//            format
            //skenario panjang pendek 7 0%
//            format.parse("01-05-2024")!!, // ⬅️ Mulai training
//            format.parse("31-08-2024")!!, // ⬅️ Akhir training (122 hari)
//            format.parse("01-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("10-10-2024")!!, // ⬅️ Akhir prediksi (10 hari)
//            format

            //skenario pendek panjang 1 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("16-07-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-08-2024")!!, // ⬅️ Akhir prediksi (46 hari)
//            format
            //skenario pendek panjang 2 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("16-07-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("30-09-2024")!!, // ⬅️ Akhir prediksi (77 hari)
//            format
            //skenario pendek panjang 3 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("01-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-10-2024")!!, // ⬅️ Akhir prediksi (61 hari)
//            format
            //skenario pendek panjang 4 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("01-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-10-2024")!!, // ⬅️ Akhir prediksi (92 hari)
//            format
            //skenario pendek panjang 5 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("01-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-10-2024")!!, // ⬅️ Akhir prediksi (31 hari)
//            format
            //skenario pendek panjang 6 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("01-11-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("30-11-2024")!!, // ⬅️ Akhir prediksi (30 hari)
//            format
            //skenario pendek panjang 7 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("15-07-2024")!!, // ⬅️ Akhir training (15 hari)
//            format.parse("01-12-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("29-12-2024")!!, // ⬅️ Akhir prediksi (29 hari)
//            format

            //skenario panjang panjang 1 DONE 0%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-08-2024")!!, // ⬅️ Akhir prediksi (31 hari)
//            format
            //skenario panjang panjang 2 DONE 0%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("30-09-2024")!!, // ⬅️ Akhir prediksi (30 hari)
//            format
            //skenario panjang panjang 3 DONE 0%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-10-2024")!!, // ⬅️ Akhir prediksi (61 hari)
//            format
            //skenario panjang panjang 4 DONE 20%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-10-2024")!!, // ⬅️ Akhir prediksi (92 hari)
//            format
            //skenario panjang panjang 5 DONE 60%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-01-2025")!!, // ⬅️ Akhir prediksi (153 hari)
//            format
            //skenario panjang panjang 6 DONE 20%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("16-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("30-10-2024")!!, // ⬅️ Akhir prediksi (77 hari)
//            format
            //skenario panjang panjang DONE 7 100%
//            format.parse("01-01-2024")!!, // ⬅️ Mulai training
//            format.parse("31-07-2024")!!, // ⬅️ Akhir training (213 hari)
//            format.parse("01-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-03-2025")!!, // ⬅️ Akhir prediksi (182 hari)
//            format

            //skenario pendek pendek 1 DONE 40%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("17-07-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("24-07-2024")!!, // ⬅️ Akhir prediksi (8 hari)
//            format
            //skenario pendek pendek 2 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("20-07-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("31-07-2024")!!, // ⬅️ Akhir prediksi (12 hari)
//            format
            //skenario pendek pendek 3 DONE 40%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("01-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("10-08-2024")!!, // ⬅️ Akhir prediksi (10 hari)
//            format
            //skenario pendek pendek 4 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("14-08-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("29-08-2024")!!, // ⬅️ Akhir prediksi (16 hari)
//            format
            //skenario pendek pendek 5 DONE 40%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("05-09-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("20-09-2024")!!, // ⬅️ Akhir prediksi (16 hari)
//            format
            //skenario pendek pendek 6 DONE 100%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("01-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("15-10-2024")!!, // ⬅️ Akhir prediksi (15 hari)
//            format
            //skenario pendek pendek 7 DONE 80%
//            format.parse("01-07-2024")!!, // ⬅️ Mulai training
//            format.parse("16-07-2024")!!, // ⬅️ Akhir training (16 hari)
//            format.parse("16-10-2024")!!, // ⬅️ Mulai prediksi
//            format.parse("29-10-2024")!!, // ⬅️ Akhir prediksi (14 hari)
//            format

            //skenario seragam 1 DONE 100%
//            format.parse("20-12-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (12 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //skenario seragam 2 DONE 100%
//            format.parse("10-12-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (22 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //skenario seragam 3 DONE 100%
//            format.parse("1-12-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (31 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //skenario seragam 4 DONE 100%
//            format.parse("1-10-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (92 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //skenario seragam 5 DONE 100%
//            format.parse("1-6-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (214 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //skenario seragam 6 DONE 100%
//            format.parse("1-1-2024")!!, // ⬅️ Mulai training
//            format.parse("31-12-2024")!!, // ⬅️ Akhir training (366 hari)
//            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
//            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
//            format
            //TODO skenario seragam 7
            format.parse("1-1-2023")!!, // ⬅️ Mulai training
            format.parse("31-12-2024")!!, // ⬅️ Akhir training (731 hari)
            format.parse("1-1-2025")!!, // ⬅️ Mulai prediksi
            format.parse("31-5-2025")!!, // ⬅️ Akhir prediksi (151 hari)
            format
        )

        val analysisResult = mutableListOf<String>()

        // 2. Normalisasi namaBarang dan kodeBarang di dataTrain
        val normalizedTransaksiList = dataTrain.map {
            it.copy(
                namaBarang = normalizeName(it.namaBarang),
                kodeBarang = normalizeName(it.kodeBarang)
            )
        }

        // 3. Ambil tanggal terakhir
        val transactionDates = dataTrain.mapNotNull {
            try {
                format.parse(it.tanggal ?: "")
            } catch (e: Exception) {
                null
            }
        }
        lastTransactionDate = transactionDates.maxOrNull() ?: Date()
        analysisResult.add("\uD83D\uDCC5 Data dianalisis untuk rekomendasi $predictionDurationDays hari ke depan.")

        // 4. Kelompokkan transaksi berdasarkan noNota
        val transaksiGrouped = normalizedTransaksiList.groupBy { it.noNota }.toSortedMap()
        val transaksiMatrix = transaksiGrouped.mapValues { (_, items) ->
            items.groupBy { it.kodeBarang }
                .mapValues { it.value.sumOf { it.qty.toDouble() } }
        }

        // 5. Hitung similarity antar barang
        val allItems = normalizedTransaksiList.map { it.kodeBarang }.distinct()
        val similarityMap = mutableMapOf<Pair<String, String>, Double>()

        for (i in allItems.indices) {
            for (j in i + 1 until allItems.size) {
                val itemA = allItems[i]
                val itemB = allItems[j]

                // Urutkan pasangan agar hanya satu versi yang masuk (misalnya "a" < "b")
                val sortedPair = if (itemA < itemB) Pair(itemA, itemB) else Pair(itemB, itemA)

                val pairedRatings = transaksiMatrix.mapNotNull { (_, items) ->
                    val qtyA = items[sortedPair.first]
                    val qtyB = items[sortedPair.second]
                    if (qtyA != null && qtyB != null) Pair(qtyA, qtyB) else null
                }

                if (pairedRatings.size >= 2) {
                    val dotProduct = pairedRatings.sumOf { it.first * it.second }
                    val magnitudeA = sqrt(pairedRatings.sumOf { it.first * it.first })
                    val magnitudeB = sqrt(pairedRatings.sumOf { it.second * it.second })
                    val similarity = if (magnitudeA != 0.0 && magnitudeB != 0.0)
                        dotProduct / (magnitudeA * magnitudeB) else 0.0

                    similarityMap[sortedPair] = similarity // ✅ hanya satu arah
                }
            }
        }

        val sortedSimilarities = similarityMap.toList().sortedByDescending { it.second }
        val top5Similarities = sortedSimilarities.take(5)
        val bottom5Similarities = sortedSimilarities.takeLast(5)

        val topRecommendations = top5Similarities.filter { it.second >= similarityThreshold }

        // 6. Tampilkan hasil rekomendasi
        analysisResult.add("\uD83D\uDCCA Rekomendasi Produk Berdasarkan Cosine Similarity:")
        topRecommendations.forEachIndexed { index, (pair, sim) ->
            analysisResult.add("${index + 1}. ${pair.first} dan ${pair.second} (similarity: ${"%.2f".format(sim)})")
        }

        // 7. Evaluasi: hitung tingkat keberhasilan di dataTest
        val rekomendasiPasangan = topRecommendations.map { it.first }
        val hasilPerKombinasi = hitungKeberhasilanPerKombinasi(rekomendasiPasangan, dataTest)
        val (jumlahCocok, totalRekomendasi) = hitungTingkatKeberhasilan(rekomendasiPasangan, dataTest)
        val persen = if (totalRekomendasi != 0) (jumlahCocok.toDouble() / totalRekomendasi) * 100 else 0.0

        analysisResult.add("")
        analysisResult.add("🎯 Evaluasi Offline: $jumlahCocok dari $totalRekomendasi pasangan cocok (${String.format("%.2f", persen)}%)")

        analysisResult.add("\n📊 Detail Evaluasi Per Kombinasi:")
        hasilPerKombinasi.forEachIndexed { index, (pair, cocok, total) ->
            val persen = if (total != 0) (cocok.toDouble() / total) * 100 else 0.0
            analysisResult.add("${index + 1}. ${pair.first} & ${pair.second} muncul di $cocok/$total transaksi pengujian (${String.format("%.2f", persen)}%)")
        }

        // 8. Tambahkan saran pemesanan ulang
        val rekomendasiPemesananUlang = mutableListOf<String>()
        topRecommendations.forEach { (pair, sim) ->
            val stokBarangA = stokList.find { normalizeName(it.kodeBarang) == pair.first }
            val stokBarangB = stokList.find { normalizeName(it.kodeBarang) == pair.second }

            if ((stokBarangA?.sisaToko ?: 0) < 10) {
                rekomendasiPemesananUlang.add("Barang ${pair.first} stok rendah → disarankan pesan ulang bersama ${pair.second} (similarity: ${"%.2f".format(sim)})")
            }
            if ((stokBarangB?.sisaToko ?: 0) < 10) {
                rekomendasiPemesananUlang.add("Barang ${pair.second} stok rendah → disarankan pesan ulang bersama ${pair.first} (similarity: ${"%.2f".format(sim)})")
            }
        }

        // 9. Kesimpulan akhir
        val kesimpulan = if (topRecommendations.isNotEmpty()) {
            val rekom = topRecommendations.joinToString("\n") { "• ${it.first.first} cocok dengan ${it.first.second}" }
            "Berikut adalah rekomendasi barang:\n$rekom"
        } else {
            "Tidak ditemukan hubungan pembelian signifikan antar produk."
        }

        analysisResult.add("\n\uD83D\uDCDD $kesimpulan")

        val jumlahTransaksiUnik = transaksiList.map { it.noNota }.toSet().size
        analysisResult.add("Jumlah transaksi total: $jumlahTransaksiUnik")

        analysisResult.add("\n\uD83D\uDCE6 Saran Pemesanan Ulang:")
        analysisResult.addAll(rekomendasiPemesananUlang)

        // 10. Tampilkan di RecyclerView
        adapter = AnalysisAdapter(analysisResult)
        binding.rvAnalysis.layoutManager = LinearLayoutManager(this)
        binding.rvAnalysis.adapter = adapter

        // 11. Simpan ke Firestore
        val todayString = format.format(Date())
        val recommendation = RecommendationResult(
            //judul = "Rekomendasi $todayString ($predictionDurationDays Hari Kedepan)",
            //TODO yang harus diubah tiap skenario
            judul = "Skenario Seragam 7 for ($predictionDurationDays Hari data input)",
            kesimpulan = kesimpulan,
            detail = analysisResult.joinToString("\n"),
            tanggal = Timestamp.now()
        )

        db.collection("recommendationResult")
            .add(recommendation)
            .addOnSuccessListener {
                Toast.makeText(this, "Berhasil disimpan ke Firestore", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Gagal menyimpan ke Firestore", Toast.LENGTH_SHORT).show()
            }
    }

    private fun checkActualData(topSimilarities: List<Pair<Pair<String, String>, Double>>) {
        if (lastTransactionDate == null) {
            Log.e("Evaluation", "Tanggal terakhir transaksi tidak tersedia.")
            return
        }

        val calendar = Calendar.getInstance()
        calendar.time = lastTransactionDate ?: Date()
        calendar.add(Calendar.DAY_OF_YEAR, 1) // mulai dari hari setelah transaksi terakhir
        val startDate = calendar.time
        calendar.add(Calendar.DAY_OF_YEAR, predictionDurationDays)
        val endDate = calendar.time

        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        Log.d("Evaluation", "Cek data aktual dari ${dateFormat.format(startDate)} hingga ${dateFormat.format(endDate)}")

        db.collection("transactions")
            .whereGreaterThanOrEqualTo("tanggal", Timestamp(startDate))
            .whereLessThanOrEqualTo("tanggal", Timestamp(endDate))
            .get()
            .addOnSuccessListener { documents ->
                val transaksiMap = mutableMapOf<String, MutableSet<String>>() // noTransaksi -> Set namaBarang
                // DEBUG: Tampilkan semua tanggal transaksi yang diambil dari Firestore
                for (doc in documents) {
                    val ts = doc.getTimestamp("tanggal")
                    Log.d("DebugTanggalFirestore", "Tanggal Firestore: $ts")
                }

                for (doc in documents) {
                    val kodeBarang = doc.getString("kodeBarang") ?: continue
                    val noNota = doc.getString("noNota") ?: continue
                    transaksiMap.getOrPut(noNota) { mutableSetOf() }.add(kodeBarang)

                }

                Log.d("Evaluation", "Transaksi setelah pengelompokan:")
                transaksiMap.forEach { (nota, items) ->
                    Log.d("Evaluation", "$nota: ${items.joinToString(", ")}")
                }

                val actualItems = transaksiMap.values.flatten().toSet()
                Log.d("Evaluation", "Barang yang benar-benar dibeli setelah prediksi:")
                actualItems.forEach { Log.d("Evaluation", it) }

                var matchedPairs = 0

                Log.d("Evaluation", "Jumlah pasangan yang cocok (prediksi vs aktual):")
                for ((pair, _) in topSimilarities) {
                    val itemA = normalizeName(pair.first)
                    val itemB = normalizeName(pair.second)
                    var matchedInTransaction = false

                    Log.d("DebugPairCheck", "Mencari pasangan: $itemA & $itemB")

                    transaksiMap.values.forEachIndexed { index, items ->
                        if (itemA in items && itemB in items) {
                            Log.d("DebugPairCheck", "✅ Ditemukan di transaksi ke-$index: ${items.joinToString(", ")}")
                            matchedInTransaction = true
                        }
                    }

                    if (matchedInTransaction) {
                        matchedPairs++
                        Log.d("Evaluation", "✅ Cocok: $itemA & $itemB")
                    } else {
                        Log.d("Evaluation", "❌ Tidak cocok: $itemA & $itemB")
                    }
                }

                Log.d("Evaluation", "Total pasangan diuji: ${topSimilarities.size}")
                Log.d("Evaluation", "Jumlah pasangan yang cocok: $matchedPairs")
            }
            .addOnFailureListener {
                Log.e("Evaluation", "Gagal mengambil data aktual: ${it.message}")
            }
    }

    // Fungsi normalisasi nama barang
    fun normalizeName(name: String): String {
        return name
            .trim()                         // hapus spasi di awal/akhir
            .lowercase()                    // huruf kecil semua
            .replace(Regex("[^a-z0-9 ]"), "") // hapus karakter selain huruf, angka, spasi
            .replace(Regex("\\s+"), " ")       // ganti spasi berulang jadi satu spasi
    }
}
