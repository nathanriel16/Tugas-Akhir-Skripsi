package com.example.recomapp.model

data class UploadFile(
    val fileName: String,
    val fileSize: String,
    val uploadProgress: Int
)