package com.example.recomapp.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.recomapp.databinding.ActivityAccountBinding
import com.example.recomapp.ui.login.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AccountActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAccountBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        binding.ivBack.setOnClickListener { onBackPressed() }
        binding.btnLogout.setOnClickListener { logoutUser() }

        loadUserData()

        binding.btnDeleteData.setOnClickListener {
            deleteAllTransactionAndStockData()
        }
    }

    private fun loadUserData() {
        val user = auth.currentUser
        if (user != null) {
            binding.tvUserEmail.text = user.email

            val userId = user.uid
            firestore.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val name = document.getString("username") ?: "User"
                        binding.tvUserName.text = name
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to load user data", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun logoutUser() {
        auth.signOut()
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun deleteAllTransactionAndStockData() {
        // Menghapus semua data dari koleksi 'transactions'
        firestore.collection("transactions").get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot) {
                    document.reference.delete()  // Menghapus setiap dokumen dalam koleksi
                }
                Toast.makeText(this, "All transaction data deleted successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to delete transaction data: ${e.message}", Toast.LENGTH_SHORT).show()
            }

        // Menghapus semua data dari koleksi 'stocks'
        firestore.collection("stocks").get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot) {
                    document.reference.delete()  // Menghapus setiap dokumen dalam koleksi
                }
                Toast.makeText(this, "All stock data deleted successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to delete stock data: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

