package com.example.recomapp.model

data class RecommendationResult(
    val judul: String = "",
    val kesimpulan: String = "",
    val detail: String = "",
    val tanggal: com.google.firebase.Timestamp? = null
)