package com.example.recomapp.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.databinding.StockItemBinding
import com.example.recomapp.model.LowStockItem

class LowStockAdapter : RecyclerView.Adapter<LowStockAdapter.LowStockViewHolder>() {

    private val items = mutableListOf<LowStockItem>()

    fun submitList(newItems: List<LowStockItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class LowStockViewHolder(private val binding: StockItemBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: LowStockItem) {
            val totalStock = item.stokToko + item.stokGudang
            binding.tvItemName.text = item.namaBarang
            binding.tvItemCode.text = item.kodeBarang
            binding.tvStockCount.text = "$totalStock pcs"

            // Low stock: indikator merah
            binding.stockIndicator.setBackgroundColor(Color.RED)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LowStockViewHolder {
        val binding = StockItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LowStockViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LowStockViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size
}
