package com.example.recomapp.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R
import com.example.recomapp.model.Stok

class StokAdapter(private val stokList: List<Stok>) :
    RecyclerView.Adapter<StokAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvKodeBarang: TextView = view.findViewById(R.id.tvKodeBarang)
        val tvNamaBarang: TextView = view.findViewById(R.id.tvNamaBarang)
        val tvStokToko: TextView = view.findViewById(R.id.tvJumlahToko)
        val tvStokGudang: TextView = view.findViewById(R.id.tvJumlahGudang)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_previewstock, parent, false)
        return ViewHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val stok = stokList[position]
        holder.tvKodeBarang.text = stok.kodeBarang
        holder.tvNamaBarang.text = stok.namaBarang
        holder.tvStokToko.text = stok.sisaToko.toString()
        holder.tvStokGudang.text = stok.sisaGudang.toString()
    }

    override fun getItemCount() = stokList.size
}
