package com.example.recomapp.ui.main

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.adapter.LowStockAdapter
import com.example.recomapp.databinding.FragmentLowStockBinding
import com.example.recomapp.model.LowStockItem
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class LowStockFragment : Fragment() {
    private lateinit var adapter: LowStockAdapter
    private lateinit var binding: FragmentLowStockBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentLowStockBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = LowStockAdapter()
        binding.rvLowStock.layoutManager = LinearLayoutManager(requireContext())
        binding.rvLowStock.adapter = adapter

        fetchAndDisplayLowStock()
    }

    private fun fetchAndDisplayLowStock() {
        val db = FirebaseFirestore.getInstance()
        val progress = binding.progressBar
        progress.visibility = View.VISIBLE

        db.collection("stocks")
            .get()
            .addOnSuccessListener { stokSnapshot ->
                val stockList = stokSnapshot.documents.mapNotNull { doc ->
                    val name = doc.getString("namaBarang")
                    val kode = doc.getString("kodeBarang")
                    val stokToko = doc.getLong("sisaToko")?.toInt() ?: 0
                    val stokGudang = doc.getLong("sisaGudang")?.toInt() ?: 0
                    val hargaJual = doc.getLong("hargajual")?.toFloat() ?: 0f
                    if (name != null && kode != null)
                        Stok(name, kode.trim().uppercase(), stokToko, stokGudang, hargaJual)
                    else null
                }
                fetchTransactionsLastWeek { txList ->
                    val needs = txList.groupBy { it.kodeBarang.trim().uppercase() }
                        .mapValues { it.value.sumOf { tx -> tx.qty } }

                    val lowItems = stockList.mapNotNull { item ->
                        val totalStock = item.sisaToko + item.sisaGudang
                        val need = needs[item.kodeBarang] ?: 0
                        if (need > 0 && totalStock < need)
                            LowStockItem(item.namaBarang, item.kodeBarang, item.sisaToko, item.sisaGudang, need - totalStock)
                        else null
                    }

                    Log.d("LowStockDebug", "Total data low stock: ${lowItems.size}")
                    adapter.submitList(lowItems)
                    progress.visibility = View.GONE
                }
            }
    }

    private fun fetchTransactionsLastWeek(onResult: (List<Transaksi>) -> Unit) {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -7) }
        val cutoff = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(cal.time)

        FirebaseFirestore.getInstance()
            .collection("transactions")
            .whereGreaterThanOrEqualTo("tanggal", cutoff)
            .get()
            .addOnSuccessListener { snap ->
                val list = snap.documents.mapNotNull { doc ->
                    val kode = doc.getString("kodeBarang")
                    val nama = doc.getString("namaBarang")
                    val tanggal = doc.getString("tanggal")
                    val qty = doc.getLong("qty")?.toInt() ?: 0
                    if (kode != null && nama != null && tanggal != null)
                        Transaksi(kode, nama, qty, tanggal)
                    else null
                }
                onResult(list)
            }
            .addOnFailureListener {
                onResult(emptyList())
            }
    }
}
