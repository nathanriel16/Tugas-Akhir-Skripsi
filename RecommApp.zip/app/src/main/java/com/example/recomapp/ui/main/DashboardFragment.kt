package com.example.recomapp.ui.main

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.R
import com.example.recomapp.adapter.NoteAdapter
import com.example.recomapp.adapter.RankingAdapter
import com.example.recomapp.databinding.DialogNoteBinding
import com.example.recomapp.databinding.FragmentDashboardBinding
import com.example.recomapp.model.Note
import com.example.recomapp.model.ProductRanking
import com.example.recomapp.model.Transaksi
import com.example.recomapp.ui.settings.SettingsActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.android.material.color.MaterialColors
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Calendar

//HALAMAN UTAMA APLIKASI
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private var noteListener: ListenerRegistration? = null
    private val binding get() = _binding!!
    private lateinit var noteAdapter: NoteAdapter
    private lateinit var rankingAdapter: RankingAdapter
    private val notes = mutableListOf<Note>()
    private val db = FirebaseFirestore.getInstance()
    private val user = FirebaseAuth.getInstance().currentUser!!
    private val rawData = mutableListOf<Pair<Date, Float>>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val view = binding.root

        // Settings button
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(context, SettingsActivity::class.java))
        }

        // Add Note button and note section
        val openNoteDialog = View.OnClickListener { showNoteDialog() }
        binding.btnAddNote.setOnClickListener(openNoteDialog)
        binding.notesSection.setOnClickListener(openNoteDialog)

        // RecyclerView setup
        noteAdapter = NoteAdapter(notes, this::showEditNoteDialog, this::deleteNote)
        binding.rvNotes.apply {
            adapter = noteAdapter
            layoutManager = LinearLayoutManager(context)
            itemAnimator = DefaultItemAnimator()
        }

        // Load username
        db.collection("users").document(user.uid).get()
            .addOnSuccessListener { document ->
                if (_binding == null) return@addOnSuccessListener
                binding.tvUsername.text = document.getString("username") ?: "User"
            }.addOnFailureListener {
                binding.tvUsername.text = "User"
            }


        // Inisialisasi adapter
        rankingAdapter = RankingAdapter()
        binding.rvRanking.adapter = rankingAdapter
        binding.rvRanking.layoutManager = LinearLayoutManager(context)

        lifecycleScope.launch {
            val chartJob = async { fetchRawSalesDataAsync() }
            val rankingJob = async { loadProductRankingAsync() }

            val rawDataResult = chartJob.await()
            rawData.clear()
            rawData.addAll(rawDataResult)

            val (labelsAll, valuesAll) = aggregateByPeriod(rawData, Period.ALL)
            updateChart(labelsAll, valuesAll, binding.trendChart)

            val rankingList = rankingJob.await()
            rankingAdapter.submitList(rankingList)
            binding.progressBarRank.visibility = View.GONE
            binding.progressBarChart.visibility = View.GONE
        }

        loadNotes()

        // Setup LineChart
        val chart: LineChart = binding.trendChart
        chart.apply {
            description.isEnabled = false
            axisRight.isEnabled = false
            legend.isEnabled = true
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
        }

        // Periodic filter
        binding.btnPeriodic.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val period = when (checkedId) {
                R.id.btn_1w -> Period.ONE_WEEK
                R.id.btn_1m -> Period.ONE_MONTH
                R.id.btn_1y -> Period.ONE_YEAR
                else        -> Period.ALL
            }
            val (labels, values) = aggregateByPeriod(rawData, period)
            updateChart(labels, values, binding.trendChart)
            binding.progressBarChart.visibility = View.GONE
        }

        return view
    }


    private fun loadNotes() {
        binding.progressBarNotes.visibility = View.VISIBLE
        noteListener = db.collection("users").document(user.uid).collection("notes")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                binding.progressBarNotes.visibility = View.GONE
                if (error != null || snapshot == null) return@addSnapshotListener
                notes.clear()
                snapshot.forEach {
                    val note = it.toObject(Note::class.java).apply { id = it.id }
                    notes.add(note)
                }
                noteAdapter.notifyDataSetChanged()
                binding.btnAddNote.visibility = View.VISIBLE
            }
    }

    private fun showNoteDialog(existingNote: Note? = null) {
        val dialogBinding = DialogNoteBinding.inflate(LayoutInflater.from(context))
        val dialog = AlertDialog.Builder(requireContext(), com.example.recomapp.R.style.DialogTheme)
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.attributes?.windowAnimations = com.example.recomapp.R.style.DialogAnimation

        dialogBinding.etNoteContent.setText(existingNote?.content ?: "")

        dialogBinding.btnSave.setOnClickListener {
            val content = dialogBinding.etNoteContent.text.toString().trim()
            if (content.isNotEmpty()) {
                val noteData = hashMapOf(
                    "content" to content,
                    "timestamp" to System.currentTimeMillis()
                )

                val notesRef = db.collection("users").document(user.uid).collection("notes")
                if (existingNote == null) {
                    notesRef.add(noteData)
                } else {
                    notesRef.document(existingNote.id).update(noteData as Map<String, Any>)
                }
                dialog.dismiss()
            } else {
                Toast.makeText(context, "Isi catatan tidak boleh kosong", Toast.LENGTH_SHORT).show()
            }
        }

        dialogBinding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showEditNoteDialog(note: Note) {
        showNoteDialog(note)
    }

    private fun deleteNote(note: Note) {
        db.collection("users").document(user.uid).collection("notes")
            .document(note.id).delete()
    }

    // 2. Agregasi data per bulan (atau per period)
    private fun aggregateByPeriod(
        data: List<Pair<Date, Float>>,
        period: Period
    ): Pair<List<String>, List<Float>> {
        val now = Date()
        val cutoff = Calendar.getInstance().apply {
            when (period) {
                Period.ONE_WEEK  -> add(Calendar.DAY_OF_YEAR, -7)
                Period.ONE_MONTH -> add(Calendar.MONTH, -1)
                Period.ONE_YEAR  -> add(Calendar.YEAR, -1)
                Period.ALL       -> time = Date(0)
            }
            // Reset jam agar tidak bentrok dengan data waktu
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time

        Log.d("ChartDebug", "🔹 Total data masuk: ${data.size}")
        Log.d("ChartDebug", "🔹 Cutoff date: $cutoff")

        val filtered = data.filter { it.first.after(cutoff) }
        Log.d("ChartDebug", "🔹 Data setelah filter: ${filtered.size}")
        filtered.forEach {
            Log.d("ChartDebug", "    🔸 ${it.first} = ${it.second}")
        }

        val keyFormatter = when (period) {
            Period.ONE_WEEK,
            Period.ONE_MONTH -> SimpleDateFormat("dd MMM", Locale.getDefault()) // per hari
            else              -> SimpleDateFormat("MMM yyyy", Locale.getDefault()) // per bulan
        }

        val grouped: Map<String, Float> = filtered
            .groupBy { keyFormatter.format(it.first) }
            .mapValues { (_, list) -> list.sumOf { it.second.toDouble() }.toFloat() }
            .toList()
            .sortedBy { (key, _) -> keyFormatter.parse(key)?.time ?: 0 }
            .toMap()

        Log.d("ChartDebug", "🔹 Grouped final:")
        grouped.forEach { (key, value) ->
            Log.d("ChartDebug", "    $key -> $value")
        }

        val labels = grouped.keys.toList()
        val values = grouped.values.toList()
        return labels to values
    }

    // 3. Gambar chart
    private fun updateChart(
        labels: List<String>,
        values: List<Float>,
        chart: LineChart
    ) {

        if (labels.isEmpty() || values.isEmpty()) {
            binding.tvChartEmpty.visibility = View.VISIBLE
            chart.visibility = View.INVISIBLE
            return
        }
        binding.tvChartEmpty.visibility = View.GONE
        chart.visibility = View.VISIBLE

        val context = chart.context

        val entries = values.mapIndexed { i, v -> Entry(i.toFloat(), v) }

        // Ambil warna dari tema
        val lineColor = MaterialColors.getColor(context, com.google.android.material.R.attr.colorPrimary, Color.BLUE)
        val axisTextColor = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnBackground, Color.BLACK)

        val dataSet = LineDataSet(entries, "Penjualan").apply {
            color = lineColor
            setCircleColor(lineColor)
            valueTextSize = 10f
            valueTextColor = axisTextColor
            lineWidth = 2f
            circleRadius = 4f
            setDrawValues(false) //untuk menghilangkan nilai pada grafik
        }

        chart.data = LineData(dataSet)

        // Sumbu X
        chart.xAxis.apply {
            valueFormatter = IndexAxisValueFormatter(labels)
            position = XAxis.XAxisPosition.BOTTOM
            textColor = axisTextColor // Ini warna teks sumbu X
            axisLineColor = axisTextColor
            labelRotationAngle = -45f
            granularity = 1f
            setDrawGridLines(false)
        }

        // Sumbu Y (kiri)
        chart.axisLeft.apply {
            textColor = axisTextColor //Ini warna teks sumbu Y
            axisLineColor = axisTextColor
            setDrawGridLines(true)
        }

        // Sumbu Y (kanan tidak digunakan)
        chart.axisRight.isEnabled = false

        // Warna legend
        chart.legend.textColor = axisTextColor

        // Refresh chart
        chart.invalidate()
    }

    private suspend fun fetchRawSalesDataAsync(): List<Pair<Date, Float>> = withContext(Dispatchers.IO) {
        val cached = getFromCache("raw_sales_data")
        if (cached != null) {
            val listType = object : TypeToken<List<Pair<Long, Float>>>() {}.type
            val parsed: List<Pair<Long, Float>> = Gson().fromJson(cached, listType)
            return@withContext parsed.map { Date(it.first) to it.second }
        }

        val snap = db.collection("transactions").orderBy("tanggal", Query.Direction.ASCENDING).get().await()
        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        val result = snap.mapNotNull { doc ->
            val tanggalStr = doc.getString("tanggal") ?: return@mapNotNull null
            val qty = doc.getDouble("qty")?.toFloat() ?: 0f
            val date = try { dateFormat.parse(tanggalStr) } catch (e: Exception) { null }
            date?.time?.let { it to qty }
        }

        // Simpan ke cache
        val json = Gson().toJson(result)
        saveToCache("raw_sales_data", json)
        rawData.clear()
        rawData.addAll(result.map { Date(it.first) to it.second })

        return@withContext result.map { Date(it.first) to it.second }
    }

    private suspend fun loadProductRankingAsync(): List<ProductRanking> = withContext(Dispatchers.IO) {
        val cached = getFromCache("ranking_data")
        if (cached != null) {
            val type = object : TypeToken<List<ProductRanking>>() {}.type
            return@withContext Gson().fromJson(cached, type)
        }

        val snap = db.collection("transactions").get().await()
        val txList = snap.mapNotNull { doc ->
            val tanggal = doc.getString("tanggal") ?: return@mapNotNull null
            val kode = doc.getString("kodeBarang") ?: return@mapNotNull null
            val nama = doc.getString("namaBarang") ?: return@mapNotNull null
            val qty = doc.getLong("qty")?.toInt() ?: doc.getDouble("qty")?.toInt() ?: 0
            Transaksi(kode, nama, qty, tanggal)
        }

        val txByProduct = txList.groupBy { it.kodeBarang }
        val monthFmt = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val last6 = (0 until 6).map {
            Calendar.getInstance().apply { add(Calendar.MONTH, -it) }
        }.reversed().map { monthFmt.format(it.time) }

        val result = txByProduct.entries.map { (kode, list) ->
            val totalSold = list.sumOf { it.qty }
            val name = list.first().namaBarang
            val monthlyMap = list.groupBy {
                val d = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).parse(it.tanggal)
                monthFmt.format(d!!)
            }.mapValues { (_, ls) -> ls.sumOf { it.qty.toDouble() }.toFloat() }
            val trend = last6.map { monthlyMap[it] ?: 0f }
            ProductRanking(
                rank = 0, productName = name, productCode = kode,
                quantity = totalSold, growthPercent = 0.0, salesTrend = trend
            )
        }.sortedByDescending { it.quantity }
            .mapIndexed { idx, pr -> pr.copy(rank = idx + 1) }

        // Simpan ke cache
        saveToCache("ranking_data", Gson().toJson(result))
        return@withContext result
    }


    enum class Period { ONE_WEEK, ONE_MONTH, ONE_YEAR, ALL }
    override fun onDestroyView() {
        super.onDestroyView()
        noteListener?.remove()  // remove Firestore listener
        _binding = null
    }
    override fun onPause() {
        super.onPause()
        noteListener?.remove()  // Stop Firestore listener when the fragment is paused
    }

    private fun getFromCache(key: String): String? {
        val sharedPref = requireContext().getSharedPreferences("dashboard_cache", 0)
        return sharedPref.getString(key, null)
    }

    private fun isCacheValid(key: String, maxAgeMillis: Long): Boolean {
        val sharedPref = requireContext().getSharedPreferences("dashboard_cache", 0)
        val lastUpdated = sharedPref.getLong("${key}_timestamp", 0L)
        return System.currentTimeMillis() - lastUpdated <= maxAgeMillis
    }

    private fun saveToCache(key: String, value: String) {
        val sharedPref = requireContext().getSharedPreferences("dashboard_cache", 0)
        sharedPref.edit()
            .putString(key, value)
            .putLong("${key}_timestamp", System.currentTimeMillis())
            .apply()
    }

}

//
//Copyright 2020 Philipp Jahoda
//
//Licensed under the Apache License, Version 2.0 (the "License");
//you may not use this file except in compliance with the License.
//You may obtain a copy of the License at
//
//http://www.apache.org/licenses/LICENSE-2.0
//
//Unless required by applicable law or agreed to in writing, software
//distributed under the License is distributed on an "AS IS" BASIS,
//WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//See the License for the specific language governing permissions and
//limitations under the License.