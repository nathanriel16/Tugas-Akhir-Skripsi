package com.example.recomapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recomapp.R

class SalesReportAdapter(
    private var items: List<ProductReport>  // ini dibuat var supaya bisa diubah
) : RecyclerView.Adapter<SalesReportAdapter.ViewHolder>() {

    data class ProductReport(
        val name: String,
        val sold: Int,
        val profit: Double,
        val imageResId: Int = R.drawable.ic_boxstorage
    )

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgProduct: ImageView = view.findViewById(R.id.imgProduct)
        val tvProductName: TextView = view.findViewById(R.id.tvProductName)
        val tvProductSold: TextView = view.findViewById(R.id.tvProductSold)
        val tvProfit: TextView = view.findViewById(R.id.tvProfit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_salesreport, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvProductName.text = item.name
        holder.tvProductSold.text = "Sold: ${item.sold}"
        holder.tvProfit.text = "Rp${String.format("%.1f", item.profit / 1000)}k"
        holder.imgProduct.setImageResource(item.imageResId)
    }

    override fun getItemCount(): Int = items.size

    // fungsi untuk update data di adapter
    fun updateData(newList: List<ProductReport>) {
        items = newList
        notifyDataSetChanged()
    }
}
