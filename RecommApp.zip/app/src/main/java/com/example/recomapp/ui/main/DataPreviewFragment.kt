package com.example.recomapp.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recomapp.adapter.StokAdapter
import com.example.recomapp.adapter.TransaksiAdapter
import com.example.recomapp.databinding.FragmentDataPreviewBinding
import com.example.recomapp.model.Stok
import com.example.recomapp.model.Transaksi
import com.google.gson.Gson
import java.io.File

//HALAMAN PARSING EXCEL UNTUK MELIHAT DATA YANG DI UPLOAD
class DataPreviewFragment : Fragment() {

    private var _binding: FragmentDataPreviewBinding? = null
    private val binding get() = _binding!!

    private lateinit var transaksiAdapter: TransaksiAdapter
    private lateinit var stokAdapter: StokAdapter

    private var transaksiList: List<Transaksi> = emptyList()
    private var stokList: List<Stok> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for the fragment
        _binding = FragmentDataPreviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val transaksiPath = arguments?.getString("transaksiPath")
        val stokPath = arguments?.getString("stokPath")

        val gson = Gson()

        transaksiList = if (transaksiPath != null) {
            val transaksiFile = File(transaksiPath)
            val transaksiType = object : com.google.gson.reflect.TypeToken<List<Transaksi>>() {}.type
            gson.fromJson(transaksiFile.readText(), transaksiType)
        } else emptyList()

        stokList = if (stokPath != null) {
            val stokFile = File(stokPath)
            val stokType = object : com.google.gson.reflect.TypeToken<List<Stok>>() {}.type
            gson.fromJson(stokFile.readText(), stokType)
        } else emptyList()


        // Setup RecyclerView for Transaksi
        transaksiAdapter = TransaksiAdapter(transaksiList)
        binding.rvTransaksi.layoutManager = LinearLayoutManager(context)
        binding.rvTransaksi.adapter = transaksiAdapter

        // Setup RecyclerView for Stok
        stokAdapter = StokAdapter(stokList)
        binding.rvStok.layoutManager = LinearLayoutManager(context)
        binding.rvStok.adapter = stokAdapter

        // Set onClickListener for Process Recommendation button
        binding.btnProcessRecommendation.isEnabled = true

        binding.btnProcessRecommendation.setOnClickListener {
            // Nonaktifkan tombol untuk menghindari double-click
            it.isEnabled = false

            // Hapus file lama jika ada
            File(requireContext().cacheDir, "transaksi.json").delete()
            File(requireContext().cacheDir, "stok.json").delete()

            val gson = Gson()
            val transaksiJson = gson.toJson(transaksiList)
            val stokJson = gson.toJson(stokList)

            // Simpan ke file cache
            val transaksiFile = File(requireContext().cacheDir, "transaksi.json")
            val stokFile = File(requireContext().cacheDir, "stok.json")
            transaksiFile.writeText(transaksiJson)
            stokFile.writeText(stokJson)

            val intent = Intent(context, RecommendationAnalysisActivity::class.java).apply {
                putExtra("transaksiFile", transaksiFile.absolutePath)
                putExtra("stokFile", stokFile.absolutePath)
            }

            startActivity(intent)
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
