package com.example.recomapp.ui.main

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.recomapp.R
import com.example.recomapp.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity(),
    BottomNavigationView.OnNavigationItemSelectedListener,
    BottomNavigationView.OnNavigationItemReselectedListener {

    private lateinit var binding: ActivityMainBinding
    private var lastClickTime: Long = 0
    private val debounceInterval = 1000 // 1 second
    private var currentFragmentId: Int = R.id.navigation_dashb

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNav.setOnNavigationItemSelectedListener(this)
        binding.bottomNav.setOnNavigationItemReselectedListener(this)

        replaceFragment(DashboardFragment())
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime > debounceInterval) {
            lastClickTime = currentTime
            if (item.itemId != currentFragmentId) {
                handleNavigation(item.itemId)
            }
        }
        return true
    }

    override fun onNavigationItemReselected(item: MenuItem) {
        val fragment = supportFragmentManager.findFragmentById(R.id.container)
        // Uncomment this if DashboardFragment supports scrollToTop:
        // if (fragment is DashboardFragment) fragment.scrollToTop()
    }

    private fun handleNavigation(itemId: Int) {
        currentFragmentId = itemId
        val fragment: Fragment = when (itemId) {
            R.id.navigation_dashb -> DashboardFragment()
            R.id.navigation_recom -> Recommendation2Fragment() //temporary
            R.id.navigation_stock -> StockMonitorFragment()
            else -> DashboardFragment()
        }
        replaceFragment(fragment)
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
    }

    override fun onBackPressed() {
        val currentFragment = supportFragmentManager.findFragmentById(R.id.container)
        if (currentFragment is DashboardFragment || currentFragment == null) {
            super.onBackPressed()
        } else {
            replaceFragment(DashboardFragment())
            binding.bottomNav.selectedItemId = R.id.navigation_dashb
        }
    }
}
