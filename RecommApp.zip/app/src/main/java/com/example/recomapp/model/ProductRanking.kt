package com.example.recomapp.model

data class ProductRanking(
    val rank: Int,
    val productName: String,
    val productCode: String,
    val quantity: Int,
    val growthPercent: Double,
    val salesTrend: List<Float>
)
